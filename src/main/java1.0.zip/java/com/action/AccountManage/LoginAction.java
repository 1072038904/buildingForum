package com.action.AccountManage;

import org.springframework.stereotype.Controller;

import com.action.common.BaseAction;
import com.model.Account;

@Controller
public class LoginAction extends BaseAction{
	private Account account =new Account();
	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}
	public LoginAction() {
	}
	public String execute() throws Exception{
		return "error";
	}
	public String Login()throws Exception{	
		if(loginService.isValid(account)==1){
			session.remove("account");
			account=loginService.findAccount(account);
//		/	UserInfor userInfor=userInforService.findEnetityByAccount(account, UserInfor.class);
			session.put("account",account);
			//session.put("userInfor", userInfor);
			
			if(account.getJurisdiction()==1)
			return "admin";
			else {
				
			//	Commodity  commodity = commodityService.recommendCommodity(userInfor);
				//session.put("reCommodity", commodity);
			return "success";
			}
		}
		else {
			session.put("tipAccount", 1);
			return "error";
		}
	}
	public String logout() {
		session.remove("account");
		return "success";
	}
}
