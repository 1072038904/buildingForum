package com.action.BoardManage;

import com.model.Board;
import com.service.BoardManage.BoardService;
import com.util.PageBean;
import net.sf.json.JSONObject;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import java.util.List;
@Controller
@ParentPackage("struts-default")
@Namespace("/")
public class BoardAction {
    @Autowired
    private BoardService boardService;
    private String json;
    @Action(
            value = "getAllBoard",
            results = {
              @Result(type="json",name="success")
            }
    )
    //获取版块数据
    public String getAllBoard(){
        PageBean pageBean=boardService.obtainAllBoardOfSection(2,3);
        JSONObject jsonObject = JSONObject.fromObject(pageBean.getList());
        json = jsonObject.toString();
        return "success";
    }
}
