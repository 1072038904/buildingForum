package com.dao.UserInforManage;
import com.dao.common.BaseDao;
import com.model.UserInfor;
public interface UserInforDao extends BaseDao<UserInfor>{


}
