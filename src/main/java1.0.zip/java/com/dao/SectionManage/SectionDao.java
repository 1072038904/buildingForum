package com.dao.SectionManage;

import com.dao.common.BaseDao;
import com.model.Section;

public interface SectionDao extends BaseDao<Section> {
}
