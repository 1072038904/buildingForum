package com.dao.AccountManage;
import com.dao.common.BaseDao;
import com.model.Account;
public interface LoginDao extends BaseDao<Account>{
	
}
