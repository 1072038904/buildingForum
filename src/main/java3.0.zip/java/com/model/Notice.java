package com.model;

import javax.persistence.*;

@Entity
public class Notice {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer id;
    //
    private String noticeContent;
    @ManyToOne
    private Account account;
}
