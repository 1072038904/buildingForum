package com.model;

import org.apache.struts2.json.annotations.JSONParameter;

import javax.persistence.*;
import java.util.Date;

@Entity
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    //评论内容
    private String content;
    //是否被阅读
    private boolean isRead;
    //是否对帖子回复
    private boolean isToPost;
    //回复排名
    private Integer replyRank;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public boolean isRead() {
        return isRead;
    }

    public void setRead(boolean read) {
        isRead = read;
    }

    public boolean isToPost() {
        return isToPost;
    }

    public void setToPost(boolean toPost) {
        isToPost = toPost;
    }

    public Integer getReplyRank() {
        return replyRank;
    }

    public void setReplyRank(Integer replyRank) {
        this.replyRank = replyRank;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    //评论对应的账号
    @ManyToOne
    @JoinColumn(name="targetAccount_id",referencedColumnName = "id")
    private Account targetAccount;
    @OneToOne
    @JoinColumn(name="account_id",referencedColumnName = "id")
    private Account account;
    @ManyToOne
    @JoinColumn(name="post_id",referencedColumnName = "id")
    private Post post;
    //发表评论的日期
    private Date date;
}
