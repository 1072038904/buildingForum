package com.dao.BoardManage;

import com.dao.common.BaseDao;
import com.model.Board;

public interface BoardDao extends BaseDao<Board>{
}
